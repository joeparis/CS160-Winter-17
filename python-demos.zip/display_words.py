def display(list):
    for item in list:
        print(item)
