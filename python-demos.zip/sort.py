def insertion_sort(word_list):
    for i in range(1, len(word_list)):

        current_value = word_list[i]
        position = i

        # check backwards through sorted list for proper position of
        # current_value
        while((position > 0) and (word_list[position - 1] > current_value)):
            word_list[position] = word_list[position - 1]
            position = position - 1

        if position != i:
            word_list[position] = current_value

    return word_list


def quick_sort(word_list):
    quick_sort_helper(word_list, 0, len(word_list) - 1)

    return word_list


def quick_sort_helper(word_list, first, last):
    if first < last:

        splitpoint = partition(word_list, first, last)

        quick_sort_helper(word_list, first, splitpoint - 1)
        quick_sort_helper(word_list, splitpoint + 1, last)


def partition(word_list, first, last):
    pivotvalue = word_list[first]

    leftmark = first + 1
    rightmark = last

    done = False
    while not done:

        while leftmark <= rightmark and word_list[leftmark] <= pivotvalue:
            leftmark = leftmark + 1

        while word_list[rightmark] >= pivotvalue and rightmark >= leftmark:
            rightmark = rightmark - 1

        if rightmark < leftmark:
            done = True
        else:
            temp = word_list[leftmark]
            word_list[leftmark] = word_list[rightmark]
            word_list[rightmark] = temp

    temp = word_list[first]
    word_list[first] = word_list[rightmark]
    word_list[rightmark] = temp

    return rightmark
