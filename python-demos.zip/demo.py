import sys
from display_words import display
from sort import insertion_sort
from sort import quick_sort
from search import sequential_search
from search import binary_search


def main():
    words_file = open('google-10000.txt', 'r', encoding='utf-8')

    words = words_file.read().split('\n')

    # sorted_list = insertion_sort(words)
    sorted_list = quick_sort(words)

    # result = sequential_search(sorted_list, sys.argv[1])
    result = binary_search(sorted_list, sys.argv[1])

    if True in result:
        output_string = "\n\"{}\" was found at position {}.\n"
        print(output_string.format(result[1], result[2]))
    else:
        output_string = "\n\"{}\" was not found.\n"
        print(output_string.format(result[1]))


if __name__ == '__main__':
    main()
