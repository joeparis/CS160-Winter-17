# iterating with "for"

for n in range(1, 11):
    print(n)

for n in [1, 2, 3, 4, 5, 6, 7, 8, 9]:
    print(n * 2)

for letter in 'abcdef':
    print(letter)
    print(letter.upper())
