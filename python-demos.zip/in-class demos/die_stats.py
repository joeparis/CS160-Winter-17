import random


def rollDie(numSides):
    return random.randrange(1, numSides + 1)


loop_count = 0
count_1 = 0
count_2 = 0
count_3 = 0
count_4 = 0
count_5 = 0
count_6 = 0
count_other = 0

while (loop_count <= 10000):
    foo = rollDie()

    if (foo == 1):
        count_1 += 1
    elif (foo == 2):
        count_2 += 1
    elif (foo == 3):
        count_3 += 1
    elif (foo == 4):
        count_4 += 1
    elif (foo == 5):
        count_5 += 1
    elif (foo == 6):
        count_6 += 1
    else:
        count_other += 1

    loop_count += 1

if (count_other > 0):
    (print "Something is horribly wrong with your six-sided die!!!")

print("You rolled " + str(count_1) + " ones, and")
print("You rolled " + str(count_2) + " twos, and")
print("You rolled " + str(count_3) + " threes, and")
print("You rolled " + str(count_4) + " fours, and")
print("You rolled " + str(count_5) + " fives, and")
print("You rolled " + str(count_6) + " sixes")
