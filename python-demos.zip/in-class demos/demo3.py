# iterating with "while"

count = 10

while count >= 0:
    print(count)
    count = count - 1

print("BLAST OFF!!!!!")
