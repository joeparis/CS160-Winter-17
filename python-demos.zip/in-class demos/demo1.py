temp = 54

if temp > 75:
    print("It's too damn hot!")
elif temp > 65:
    print("A little too warm for me")
else:
    print("Perfect!")
