for n in range(1, 6):
    for l in ('abcd'):
        print('{}{}'.format(n, l))
