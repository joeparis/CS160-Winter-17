from profile import *


@profile
def insertion_sort(word_list):
    for i in range(1, len(word_list)):

        current_value = word_list[i]
        position = i

        # check backwards through sorted list for proper position of
        # current_value
        while((position > 0) and (word_list[position - 1] > current_value)):
            word_list[position] = word_list[position - 1]
            position = position - 1

        if position != i:
            word_list[position] = current_value


@profile
def quick_sort(word_list):
    quick_sort_helper(word_list, 0, len(word_list) - 1)


def quick_sort_helper(word_list, first, last):
    if first < last:

        splitpoint = partition(word_list, first, last)

        quick_sort_helper(word_list, first, splitpoint - 1)
        quick_sort_helper(word_list, splitpoint + 1, last)


def partition(word_list, first, last):
    pivotvalue = word_list[first]

    leftmark = first + 1
    rightmark = last

    done = False
    while not done:

        while leftmark <= rightmark and word_list[leftmark] <= pivotvalue:
            leftmark = leftmark + 1

        while word_list[rightmark] >= pivotvalue and rightmark >= leftmark:
            rightmark = rightmark - 1

        if rightmark < leftmark:
            done = True
        else:
            temp = word_list[leftmark]
            word_list[leftmark] = word_list[rightmark]
            word_list[rightmark] = temp

    temp = word_list[first]
    word_list[first] = word_list[rightmark]
    word_list[rightmark] = temp

    return rightmark


@profile
def sequential_search(word_list, target):
    if not word_list:
        return 'nope!'

    position = 0
    found = False

    while position < len(word_list) and not found:
        if word_list[position] == target:
            found = True
            break
        else:
            position = position + 1


@profile
def binary_search(word_list, target):
    first = 0
    last = len(word_list) - 1
    found = False

    while first <= last and not found:
        midpoint = (first + last) // 2
        if word_list[midpoint] == target:
            found = True
        else:
            if target < word_list[midpoint]:
                last = midpoint - 1
            else:
                first = midpoint + 1


def main():
    print('Running...')

    words = open('google-10000.txt', 'r', encoding='utf-8').read().split('\n')
    insertion_sort(words)

    words = open('google-10000.txt', 'r', encoding='utf-8').read().split('\n')
    quick_sort(words)

    words = open('google-10000-sorted.txt', 'r',
                 encoding='utf-8').read().split('\n')
    sequential_search(words, "the")

    binary_search(words, "the")

    print_prof_data()

    clear_prof_data()


if __name__ == '__main__':
    main()
