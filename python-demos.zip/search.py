def sequential_search(word_list, target):
    if not word_list:
        return 'nope!'

    position = 0
    found = False

    while position < len(word_list) and not found:
        if word_list[position] == target:
            found = True
            break
        else:
            position = position + 1

    return found, target, position


def binary_search(word_list, target):
    first = 0
    last = len(word_list) - 1
    found = False

    while first <= last and not found:
        midpoint = (first + last) // 2
        if word_list[midpoint] == target:
            found = True
        else:
            if target < word_list[midpoint]:
                last = midpoint - 1
            else:
                first = midpoint + 1

    return found, target, midpoint
